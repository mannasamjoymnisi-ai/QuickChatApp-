/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registrationloginapp;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Student
 */
public final class MessageManager {
     public static final int MAX_MESSAGES = 100;
    public static final Scanner scan = new Scanner(System.in);
    public static final Random random = new Random();
    public static final String STORE_FILE = "storedMessages.json";

    // Parallel arrays: index i refers to the same message in every array.
    public final String[] allIDs = new String[MAX_MESSAGES];
    public final String[] allHashes = new String[MAX_MESSAGES];
    public final String[] allRecipient = new String[MAX_MESSAGES];
    public final String[] allMessages = new String[MAX_MESSAGES];
    public final String[] allStatus = new String[MAX_MESSAGES];

    // The five assignment arrays (message IDs and hashes are parallel too).
    public final String[] sentMessages = new String[MAX_MESSAGES];
    public final String[] disregardedMessages = new String[MAX_MESSAGES];
    public final String[] storedMessages = new String[MAX_MESSAGES];
    public final String[] messageHashes = allHashes;
    public final String[] messageIDs = allIDs;

    public int totalMessages = 0;
    public int totalSent = 0;
    public int sentCount = 0;
    public int disregardedCount = 0;
    public int storedCount = 0;

    public MessageManager () { 
        loadStoredMessages();
    }

    public void displayM() {
        int opt = 0;
        do {
            System.out.println("\nWelcome to QuickChat");
            System.out.println("1. Send messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Quit");
            System.out.println("4. Stored Messages");
            System.out.print("Choose an option: ");

            if (!scan.hasNextInt()) {
                System.out.println("Error: please enter a number.");
                scan.nextLine();
                continue;
            }
            opt = scan.nextInt();
            scan.nextLine();

            switch (opt) {
                case 1 -> sendMessages();
                case 2 -> System.out.println(printMessages());
                case 3 -> System.out.println("Goodbye.");
                case 4 -> displayStoredMenu();
                default -> System.out.println("Error: invalid input.");
            }
        } while (opt != 3);
    }

    public void sendMessages() {
        if (totalMessages >= MAX_MESSAGES) {
            System.out.println("Message storage is full.");
            return;
        }
        System.out.print("How many messages? ");
        if (!scan.hasNextInt()) {
            System.out.println("Please enter a whole number.");
            scan.nextLine();
            return;
        }
        int numberOfMessages = scan.nextInt();
        scan.nextLine();
        if (numberOfMessages <= 0) {
            System.out.println("Enter at least one message.");
            return;
        }

        for (int i = 0; i < numberOfMessages && totalMessages < MAX_MESSAGES; i++) {
            System.out.println("\nMessage " + (i + 1));
            System.out.print("Enter recipient cellphone number: ");
            String recipient = scan.nextLine().trim();
            String recipientResult = checkRecipientCell(recipient);
            System.out.println(recipientResult);
            if (!recipientResult.equals("Cell phone number successfully captured.")) {
                System.out.println("Message not processed.");
                continue;
            }

            System.out.print("Enter message (maximum 250 characters): ");
            String message = scan.nextLine();
            String messageResult = checkMessage(message);
            System.out.println(messageResult);
            if (!messageResult.equals("Message ready to send.")) {
                System.out.println("Message not processed.");
                continue;
            }

            String id = String.valueOf(random.nextInt(1_000_000_000));
            while (!checkMessageID(id) || findIndexByID(id) >= 0) {
                id = String.valueOf(random.nextInt(1_000_000_000));
            }
            String hash = createMessageHash(id, totalMessages + 1, message);
            System.out.println("Message ID: " + id);
            System.out.println("Message hash: " + hash);
            System.out.println(sentMessage(id, hash, recipient, message));
        }
    }

    public boolean checkMessageID(String id) {
        return id != null && !id.isEmpty() && id.length() <= 10;
    }

    public String checkRecipientCell(String cell) {
        if (cell == null) return "Invalid cellphone number.";
        if (cell.matches("\\+27\\d{9}") || cell.matches("0\\d{9}")) {
            return "Cell phone number successfully captured.";
        }
        return "Invalid cellphone number. Use 0XXXXXXXXX or +27XXXXXXXXX.";
    }

    public String checkMessage(String message) {
        if (message == null || message.trim().isEmpty()) return "Please enter a message.";
        if (message.length() > 250) return "Please enter a message of no more than 250 characters.";
        return "Message ready to send.";
    }

    public String createMessageHash(String id, int numSent, String message) {
        if (id == null || id.isEmpty() || message == null || message.trim().isEmpty()) return "";
        String[] words = message.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        String idPart = id.substring(0, Math.min(2, id.length()));
        return (idPart + ":" + numSent + ":" + firstWord + lastWord).toUpperCase();
    }

    public String sentMessage(String id, String hash, String recipient, String message) {
        System.out.println("\nChoose:");
        System.out.println("1. Send Message");
        System.out.println("2. Disregard Message");
        System.out.println("3. Store Message");
        System.out.print("Your choice: ");
        if (!scan.hasNextInt()) {
            System.out.println("Invalid option.");
            scan.nextLine();
            return "Message was not processed.";
        }
        int choice = scan.nextInt();
        scan.nextLine();

        if (choice == 1) {
            addMessage(id, hash, recipient, message, "SENT");
            return "Message successfully sent.";
        } else if (choice == 2) {
            addMessage(id, hash, recipient, message, "DISREGARDED");
            return "Message disregarded.";
        } else if (choice == 3) {
            addMessage(id, hash, recipient, message, "STORED");
            saveStoredMessages();
            return "Message successfully stored.";
        }
        return "Invalid option. Message was not processed.";
    }

    /** Public so it can also be used by unit tests. */
    public boolean addMessage(String id, String hash, String recipient, String message, String status) {
        if (totalMessages >= MAX_MESSAGES || id == null || hash == null || recipient == null || message == null) {
            return false;
        }
        if (findIndexByID(id) >= 0) return false;
        allIDs[totalMessages] = id;
        allHashes[totalMessages] = hash;
        allRecipient[totalMessages] = recipient;
        allMessages[totalMessages] = message;
        allStatus[totalMessages] = status;
        if ("SENT".equals(status)) {
            sentMessages[sentCount++] = message;
            totalSent++;
        } else if ("DISREGARDED".equals(status)) {
            disregardedMessages[disregardedCount++] = message;
        } else if ("STORED".equals(status)) {
            storedMessages[storedCount++] = message;
        }
        totalMessages++;
        return true;
    }

    public String printMessages() {
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < totalMessages; i++) {
            if ("SENT".equals(allStatus[i])) {
                output.append("Message ID: ").append(allIDs[i]).append('\n')
                      .append("Message Hash: ").append(allHashes[i]).append('\n')
                      .append("Recipient: ").append(allRecipient[i]).append('\n')
                      .append("Message: ").append(allMessages[i]).append("\n\n");
            }
        }
        return output.length() == 0 ? "No sent messages in this session." : output.toString();
    }

    public int returnTotalMessages(int num) { return num; }

    public void displayStoredMenu() {
        int option = 0;
        do {
            System.out.println("\n--- Stored Messages ---");
            System.out.println("1. Show sender and recipient of stored messages");
            System.out.println("2. Find longest stored message");
            System.out.println("3. Search stored message by ID");
            System.out.println("4. Show all stored messages for a recipient");
            System.out.println("5. Delete stored message by hash");
            System.out.println("6. Display report of all stored messages");
            System.out.println("7. Return to main menu");
            System.out.print("Choose an option: ");
            if (!scan.hasNextInt()) { System.out.println("Enter a number."); scan.nextLine(); continue; }
            option = scan.nextInt();
            scan.nextLine();
            switch (option) {
                case 1 -> showSendersAndRecipients();
                case 2 -> System.out.println(findLongestStoredMessage());
                case 3 -> {
                    System.out.print("Enter message ID: ");
                    System.out.println(searchStoredByID(scan.nextLine().trim()));
                }
                case 4 -> {
                    System.out.print("Enter recipient number: ");
                    System.out.println(searchStoredByRecipient(scan.nextLine().trim()));
                }
                case 5 -> {
                    System.out.print("Enter message hash to delete: ");
                    System.out.println(deleteStoredByHash(scan.nextLine().trim()));
                }
                case 6 -> System.out.println(displayStoredReport());
                case 7 -> {
                }
                default -> System.out.println("Invalid option.");
            }
        } while (option != 7);
    }

    public String showSendersAndRecipients() {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < totalMessages; i++) if ("STORED".equals(allStatus[i])) {
            out.append("Sender: User | Recipient: ").append(allRecipient[i]).append('\n');
        }
        String result = out.length() == 0 ? "No stored messages." : out.toString();
        System.out.print(result);
        return result;
    }

    public String findLongestStoredMessage() {
        int longestIndex = -1;
        for (int i = 0; i < totalMessages; i++) {
            if ("STORED".equals(allStatus[i]) &&
                    (longestIndex == -1 || allMessages[i].length() > allMessages[longestIndex].length())) {
                longestIndex = i;
            }
        }
        return longestIndex == -1 ? "No stored messages." : "Longest stored message: " + allMessages[longestIndex];
    }

    public String searchStoredByID(String id) {
        int index = findIndexByID(id);
        if (index < 0 || !"STORED".equals(allStatus[index])) return "No stored message found with ID " + id + ".";
        return "Recipient: " + allRecipient[index] + "\nMessage: " + allMessages[index];
    }

    public String searchStoredByRecipient(String recipient) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < totalMessages; i++) if ("STORED".equals(allStatus[i]) && allRecipient[i].equals(recipient)) {
            out.append("Message ID: ").append(allIDs[i]).append(" | Message: ").append(allMessages[i]).append('\n');
        }
        return out.length() == 0 ? "No stored messages found for recipient " + recipient + "." : out.toString();
    }

    public String deleteStoredByHash(String hash) {
        for (int i = 0; i < totalMessages; i++) {
            if ("STORED".equals(allStatus[i]) && allHashes[i].equals(hash)) {
                removeAt(i);
                rebuildCategoryArrays();
                saveStoredMessages();
                return "Stored message deleted.";
            }
        }
        return "No stored message found with that hash.";
    }

    public String displayStoredReport() {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < totalMessages; i++) if ("STORED".equals(allStatus[i])) {
            out.append("Message ID: ").append(allIDs[i]).append('\n')
               .append("Message Hash: ").append(allHashes[i]).append('\n')
               .append("Recipient: ").append(allRecipient[i]).append('\n')
               .append("Message: ").append(allMessages[i]).append("\n\n");
        }
        return out.length() == 0 ? "No stored messages." : out.toString();
    }

    private int findIndexByID(String id) {
        for (int i = 0; i < totalMessages; i++) if (allIDs[i].equals(id)) return i;
        return -1;
    }

    private void removeAt(int index) {
        for (int i = index; i < totalMessages - 1; i++) {
            allIDs[i] = allIDs[i + 1]; allHashes[i] = allHashes[i + 1];
            allRecipient[i] = allRecipient[i + 1]; allMessages[i] = allMessages[i + 1];
            allStatus[i] = allStatus[i + 1];
        }
        totalMessages--;
        allIDs[totalMessages] = null; allHashes[totalMessages] = null;
        allRecipient[totalMessages] = null; allMessages[totalMessages] = null; allStatus[totalMessages] = null;
    }

    private void rebuildCategoryArrays() {
        sentCount = 0; disregardedCount = 0; storedCount = 0; totalSent = 0;
        clearArray(sentMessages); clearArray(disregardedMessages); clearArray(storedMessages);
        for (int i = 0; i < totalMessages; i++) {
            if ("SENT".equals(allStatus[i])) { sentMessages[sentCount++] = allMessages[i]; totalSent++; }
            else if ("DISREGARDED".equals(allStatus[i])) disregardedMessages[disregardedCount++] = allMessages[i];
            else if ("STORED".equals(allStatus[i])) storedMessages[storedCount++] = allMessages[i];
        }
    }

    private void clearArray(String[] array) { for (int i = 0; i < array.length; i++) array[i] = null; }

    /** Loads stored messages on startup. Uses only Java's built-in libraries. */
    public void loadStoredMessages() {
        File file = new File(STORE_FILE);
        if (!file.exists()) return;
        try {
            String contents = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
            Matcher objects = Pattern.compile("\\{(.*?)\\}", Pattern.DOTALL).matcher(contents);
            while (objects.find() && totalMessages < MAX_MESSAGES) {
                String object = objects.group(1);
                String id = jsonValue(object, "MessageID");
                String hash = jsonValue(object, "MessageHash");
                String recipient = jsonValue(object, "Recipient");
                String message = jsonValue(object, "Message");
                if (id != null && hash != null && recipient != null && message != null && findIndexByID(id) < 0) {
                    addMessage(id, hash, recipient, message, "STORED");
                }
            }
        } catch (IOException e) {
            System.out.println("Could not load stored messages: " + e.getMessage());
        }
    }

    /** Rewrites the JSON file so it contains the current stored messages only. */
    public void saveStoredMessages() {
        try (FileWriter writer = new FileWriter(STORE_FILE, false)) {
            writer.write("[\n");
            boolean first = true;
            for (int i = 0; i < totalMessages; i++) if ("STORED".equals(allStatus[i])) {
                if (!first) writer.write(",\n");
                writer.write("  {\"MessageID\":\"" + escapeJson(allIDs[i]) + "\","
                        + "\"MessageHash\":\"" + escapeJson(allHashes[i]) + "\","
                        + "\"Recipient\":\"" + escapeJson(allRecipient[i]) + "\","
                        + "\"Message\":\"" + escapeJson(allMessages[i]) + "\"}");
                first = false;
            }
            writer.write("\n]\n");
        } catch (IOException e) {
            System.out.println("Error saving stored messages: " + e.getMessage());
        }
    }

    private String jsonValue(String object, String key) {
        Pattern p = Pattern.compile("\\\"" + Pattern.quote(key) + "\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\"\\\\])*)\\\"", Pattern.DOTALL);
        Matcher m = p.matcher(object);
        return m.find() ? unescapeJson(m.group(1)) : null;
    }

    private String escapeJson(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }

    private String unescapeJson(String value) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c == '\\' && i + 1 < value.length()) {
                char next = value.charAt(++i);
                switch (next) {
                    case 'n' -> out.append('\n');
                    case 'r' -> out.append('\r');
                    case 't' -> out.append('\t');
                    case '"' -> out.append('"');
                    case '\\' -> out.append('\\');
                    case '/' -> out.append('/');
                    default -> out.append(next);
                }
            } else out.append(c);
        }
        return out.toString();
    }
}

    

